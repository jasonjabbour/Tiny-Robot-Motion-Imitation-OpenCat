It's nasty to include the **src/** libraries here rather than Arduino's desinated library folder, especially when we have to duplicate the **src/** in two layers within the same project folder.  

We put them here only to help those users who are new to Arduino and complained about the difficulties of configuring the Arduino environment. You may find more informative comments within those library files. 
