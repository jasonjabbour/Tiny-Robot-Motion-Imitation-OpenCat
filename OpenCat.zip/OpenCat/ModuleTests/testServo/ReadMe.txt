The video for the tests can be found at https://youtu.be/vCvjGVeO57g

Datasheet is at https://docs.google.com/spreadsheets/d/1R2a6Q3H9Heo5MBXjv3MdyxipxWbeRYw3lmymrDakhaY/edit?usp=sharing
